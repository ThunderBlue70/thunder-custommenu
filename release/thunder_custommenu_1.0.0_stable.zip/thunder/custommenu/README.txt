Thunder Custom Menu 1.0.4

Configurable menu for phpBB 3.3.x. Integrated header position with rounded lower corners, hover dropdowns, and simple ACP menu editor.
